const API_URI = "";
const API_URL_LIST = {
  ToDoList: {
    method: "get",
    url: "url",
    isSecure: false,
    isTokenRequire: false,
  },
  ToDoListADD: {
    method: "post",
    url: "url",
    isSecure: false,
    isTokenRequire: false,
  },
};
export { API_URI, API_URL_LIST };
